getUserMedia-API-Simple-App-Example
===================================

 A very simple WebCam control app sample powered with HTML5, jQuery and Canvas.
 
 This is the source code I have developed to write the article "Controlando nuestra WebCam con HTML5" available at http://www.eduardocasas.com/blog/07-01-2013/controlando-nuestra-webcam-con-html5
